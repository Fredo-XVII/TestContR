context("test-match_numeric.R")

test_that("multiplication works", {
  expect_equal(2 * 2, 4)
})
