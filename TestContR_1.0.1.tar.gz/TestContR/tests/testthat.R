library(testthat)
library(TestContR)

test_check("TestContR")
